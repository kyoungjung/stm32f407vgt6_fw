/*
 * ap.h
 *
 *  Created on: 2023. 9. 5.
 *      Author: kjkim
 */

#ifndef SRC_AP_AP_H_
#define SRC_AP_AP_H_

#include "hw.h"

void apInit(void);
void apMain(void);


#endif /* SRC_AP_AP_H_ */
